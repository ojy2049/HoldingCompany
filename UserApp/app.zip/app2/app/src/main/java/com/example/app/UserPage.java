package com.example.app;


import android.os.Bundle;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import net.daum.mf.map.api.MapView;
import android.support.v4.widget.DrawerLayout;
public class UserPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpage);

        final DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
    }
}
