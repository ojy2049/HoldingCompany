package com.example.app;

import com.google.gson.annotations.SerializedName;


public class Result {
    @SerializedName("token")
    private String token;

    public String toString(){
        return "result{"+
                "token="+token+
                '}';
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
