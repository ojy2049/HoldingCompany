package com.example.app;


import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by sonchangwoo on 2017. 1. 1..
 */

public interface ResApi {

    @FormUrlEncoded
    @POST("login")
    Call<Result> getPosts(@Field("token") String token);

}